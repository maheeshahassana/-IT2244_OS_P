#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
#include <pthread.h>

//a normal c function that is executed as a thread
//when its name is specified in pthread_create()

void *helloworld(void *vargp){
	sleep(1);
	printf("hello world \n");
	return NULL;
}
 int main(){
	 pthread_t thread_id;
	 printf("before thread\n");
	 pthread_create(&thread_id,NULL,helloworld,NULL);
	 pthread_join(thread_id,NULL);
	 printf("after thread \n");
	 exit(0);
 }