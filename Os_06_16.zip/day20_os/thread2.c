#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

// Thread function
void *helloworld(void *vargp) {
    sleep(1);
    printf("Hello, World!\n");
    return NULL;
}

int main() {
    pthread_t thread_id;
    
    printf("Before thread\n");
    
    // Create the thread
    if (pthread_create(&thread_id, NULL, helloworld, NULL) != 0) {
        perror("Failed to create thread");
        return 1; // Return error if thread creation fails
    }

    // Wait for the thread to finish
    if (pthread_join(thread_id, NULL) != 0) {
        perror("Failed to join thread");
        return 1;
    }
    
    printf("After thread\n");
    return 0;
}
