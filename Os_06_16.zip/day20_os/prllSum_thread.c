#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define SIZE 6

int arr[SIZE] = {1, 2, 3, 4, 5, 6};
int sum1 = 0, sum2 = 0;

// Function for first half of the sum
void* sum_part1(void* arg) {
    for (int i = 0; i < SIZE / 2; i++) {
        sum1 += arr[i];
    }
    return NULL;
}

// Function for second half of the sum
void* sum_part2(void* arg) {
    for (int i = SIZE / 2; i < SIZE; i++) {
        sum2 += arr[i];
    }
    return NULL;
}

int main() { // Fixed main function declaration
    pthread_t thread1, thread2;

    // Create threads
    pthread_create(&thread1, NULL, sum_part1, NULL);
    pthread_create(&thread2, NULL, sum_part2, NULL);

    // Wait for threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Compute final sum
    int total_sum = sum1 + sum2;
    printf("Total Sum: %d\n", total_sum);

    return 0;
}
