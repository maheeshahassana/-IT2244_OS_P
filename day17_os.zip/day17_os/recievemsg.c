#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct mesg_buffer{
	long mesg_type;
	char mesg_text[100];
}message;
int main(){
	key_t key;
	int msgid;
// ftok to generate unique key
key=ftok("progfiule",65);
//msgget creates a message queue
//and return identifier
msgid=msgget(key,0666|IPC_CREAT);

//msgsnd to send message
msgrcv(msgid, &message,sizeof(message),1,0);
//display the message
printf("data recieved is:%s \n",message.mesg_text);
//to destroy the message queue
msgctl(msgid,IPC_RMID,NULL);
return 0;
}