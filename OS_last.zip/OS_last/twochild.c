parent have 2 child one child get array of 5 numbers another child sorted the array
 parent is print largest number
 
 #include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// Function to sort the array (in-place)
void sort_array(int *arr, int size) {
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (arr[i] > arr[j]) {
                int tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
            }
}

int main() {
    int pipe1[2]; // Child 1 to Parent
    int pipe2[2]; // Parent to Child 2
    int pipe3[2]; // Child 2 to Parent
    int size = 5;

    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t child1 = fork();
    if (child1 == 0) {
        // Child 1: send array to parent
        close(pipe1[0]);
        int arr[] = {42, 17, 8, 99, 23};
        write(pipe1[1], arr, sizeof(arr));
        close(pipe1[1]);
        exit(0);
    }

    pid_t child2 = fork();
    if (child2 == 0) {
        // Child 2: receive array, sort it, send back
        close(pipe2[1]);
        int arr[size];
        read(pipe2[0], arr, sizeof(arr));
        sort_array(arr, size);
        close(pipe2[0]);

        close(pipe3[0]);
        write(pipe3[1], arr, sizeof(arr));
        close(pipe3[1]);
        exit(0);
    }

    // Parent process
    close(pipe1[1]);
    int received[size];
    read(pipe1[0], received, sizeof(received));
    close(pipe1[0]);

    close(pipe2[0]);
    write(pipe2[1], received, sizeof(received));
    close(pipe2[1]);

    close(pipe3[1]);
    int sorted[size];
    read(pipe3[0], sorted, sizeof(sorted));
    close(pipe3[0]);

    wait(NULL); // Wait for child 1
    wait(NULL); // Wait for child 2

    printf("Sorted array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", sorted[i]);
    }
    printf("\nLargest number: %d\n", sorted[size - 1]);

    return 0;
}
