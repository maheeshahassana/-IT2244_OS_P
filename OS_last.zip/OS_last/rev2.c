#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
	int fd[2];
	pid_t pid;
	int arr[]={1,2,3,4,5};
	int size =sizeof(arr);
	
	if(pipe(fd)==-1){
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	
	pid=fork();
	if(pid<0){
		perror("fork");
		exit(EXIT_FAILURE);
	}
	
	if(pid==0){
		close(fd[0]);
		write(fd[1],arr,size);
		close(fd[1]);
		exit(EXIT_SUCCESS);
	}else{
		
		close(fd[1]);
		int received[5];
		read(fd[0],received,size);
		close(fd[0]);
		
		printf("parent received array: ");
		for(int i=0;i<5;i++){
			printf(received[i]);
		}
		printf("\n");
		wait();
	}
	return 0;
}