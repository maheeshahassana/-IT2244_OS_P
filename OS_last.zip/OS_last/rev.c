child write array using pipe arr=[1,2,3,4,5]
parent as read the array  and show both pid and parent id so,write the code in c language in os

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    int pipefd[2];
    pid_t pid;
    int arr[] = {1, 2, 3, 4, 5};
    int buffer[5];

    // Create the pipe
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid = fork(); // Create child process

    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {  // Child process
        close(pipefd[0]); // Close unused read end
        write(pipefd[1], arr, sizeof(arr));
        printf("Child Process:\n");
        printf("  PID       = %d\n", getpid());
        printf("  Parent ID = %d\n", getppid());
        close(pipefd[1]); // Close write end
    } else {  // Parent process
        close(pipefd[1]); // Close unused write end
        read(pipefd[0], buffer, sizeof(buffer));
        close(pipefd[0]); // Close read end

        printf("Parent Process:\n");
        printf("  PID       = %d\n", getpid());
        printf("  Child PID = %d\n", pid);
        printf("  Received Array: ");
        for (int i = 0; i < 5; i++) {
            printf("%d ", buffer[i]);
        }
        printf("\n");
    }

    return 0;
}
