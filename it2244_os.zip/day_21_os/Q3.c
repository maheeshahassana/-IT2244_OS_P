#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> // For sleep()

void* print_numbers(void* arg) {
    for (int i = 1; i <= 10; i++) {
        printf("Number: %d\n", i);
        sleep(1); // Pause for 1 second
    }
    return NULL;
}

int main() {
    pthread_t thread;

    // Create the thread
    if (pthread_create(&thread, NULL, print_numbers, NULL) != 0) {
        perror("Failed to create thread");
        return 1;
    }

    // Wait for the thread to finish
    pthread_join(thread, NULL);

    printf("Main thread: Number printing completed.\n");
    return 0;
}
