#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* square_number(void* arg) {
    int num = *((int*)arg);
    int* result = malloc(sizeof(int)); // allocate memory to store the result
    if (result == NULL) {
        perror("Memory allocation failed");
        pthread_exit(NULL);
    }
    *result = num * num;
    pthread_exit(result);
}

int main() {
    pthread_t thread;
    int input = 7; // You can change this to any number
    int* result;

    // Create the thread and pass the input number
    if (pthread_create(&thread, NULL, square_number, &input) != 0) {
        perror("Thread creation failed");
        return 1;
    }

    // Wait for the thread to finish and collect the result
    if (pthread_join(thread, (void**)&result) != 0) {
        perror("Thread join failed");
        return 1;
    }

    printf("Square of %d is %d\n", input, *result);

    // Clean up
    free(result);

    return 0;
}
